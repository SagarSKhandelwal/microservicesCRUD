Flask
Flask-RESTful
Flask-JWT
Flask-SQLAlchemy
uwsgi
